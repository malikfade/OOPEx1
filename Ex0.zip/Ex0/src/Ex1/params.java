package Ex1;

public class params {
int Resolution;
double[] Range_X;
double[] Range_Y;
int Height;
int Width;
}